import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tugaspemogramanmobile11/component/KategoriItem.dart';
import 'package:tugaspemogramanmobile11/database/kategoriDB.dart';
import 'package:tugaspemogramanmobile11/kategoriIconScreen.dart';
import 'package:tugaspemogramanmobile11/values/bahasa.dart';

import 'function.dart';

class Kelompok extends StatefulWidget {
  @override
  _KelompokState createState() => _KelompokState();
}

class _KelompokState extends State<Kelompok> {
  final List bulan = [
    "Alfrizal Panji Mahendra (20180801070)",
    "David Siswanto (20180801197)",
    "S.Rimbayu Tia Pratika (20180801111)",
    "Rangga Wahyu Pratama (20180801023)",
    "Putra Dwi Andhika (20180801100)",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: Text('Daftar Kelompok'),
      ),
      body: ListView.builder(
        itemBuilder: (context, index) {
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text(bulan[index], style: TextStyle(fontSize: 20)),
            ),
          );
        },
        itemCount: bulan.length,
      ),
    );
  }
}
